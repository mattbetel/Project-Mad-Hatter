from twilio.rest import Client
from twilio.twiml.messaging_response import MessagingResponse
from flask import Flask, request
from watson_developer_cloud import AssistantV1
import simplejson as json
import re

# Find these values at https://twilio.com/user/account

print("Launching app")
account_sid = "AC7902bd3e3cac20e76c18122048747756"
auth_token = "75df92ee13f40b106aac8606081b7aa0"
client = Client(account_sid, auth_token)
app = Flask(__name__)

@app.route("/respond", methods=['POST'])
def respond():
    number = request.values.get('From', None)
    message_body = request.values.get('Body', None)
    print("Message recieved: %s ... getting watson response", message_body)
    chatbot_resp = get_watson_response(message_body)
    print("Recieved response from watson: ", chatbot_resp)
    send_response(chatbot_resp, number)
    # for message_response in chatbot_resp:
    #     resp = MessagingResponse()
    #     resp.message(message_response)
    #     return str(resp)

# Created function instead of returning to break up messages
def send_response(chatbot_resp, to_number):
    for message_response in chatbot_resp:
        message_response = clean_html(message_response)
        client.api.account.messages.create(
            to=to_number,
            from_="+16476979131",
            body= message_response)

def strip_html(response):
    if '<a href="' in response:
        response.replace('<a href="', '')
    if '</a>' in response:
        response.replace('</a>', '')
    if '<' in response:
        response.replace('<', '')
    if '>' in response:
        response.replace('>', '')


def clean_html(raw_html):
    if "mailto:" in raw_html:
        lower_bound = raw_html.split('"')
        upper_bound = lower_bound[1].split('?')
        email = upper_bound[0].split('"')[0]
        cleanr = re.compile('<.*?>')
        cleantext = re.sub(cleanr, '', raw_html)
        cleantext = cleantext + " (attached email: " + str(email) + ")"
        return cleantext
    else:
        return raw_html


def get_watson_response(message_input):
    try:
        print("Initializing watson assistant")
        workspace_id = "65c240d7-323a-45b5-9f82-42ee1c25e111"
        assistant = AssistantV1(
            username='2dcb58b9-818a-43ba-818a-779c4c41cb0a',
            password='7pEptkXA1meA',
            version='2017-04-21')
        assistant.set_http_config({'timeout': 100})
        response = assistant.message(workspace_id=workspace_id, input={
            'text': message_input})
        output = response["output"]["text"]
        return output
    except Exception as e:
        print(e)
        return "Could not initialize watson"
        
     # Print the output from dialog, if any.
    if response['output']['text']:
        print(response['output']['text'][0])

if __name__ == "__main__":
    app.run(debug=True)