import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

msg = MIMEMultipart()
msg ['From'] = "theprojectmadhatter@gmail.com"
msg['To'] = "tracy.jenkin@queensu.ca"
msg['Subject'] = "Chat Bot Low Confidence"


body = "A student asked a question and it responded with a low confidence answer"
msg.attach(MIMEText(body))
print(msg)

server = smtplib.SMTP('smtp.gmail.com', 587)
server.starttls()
server.login(msg['From'], 'COMM493COMM493')
server.sendmail(msg['From'], msg['to'], msg.as_string())
server.quit()